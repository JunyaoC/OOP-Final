interface DiscConsiderable{

	final static double DISC_KIDS = 100;
	final static double DISC_SENIOR = 10;

	public double calcDisc();
}